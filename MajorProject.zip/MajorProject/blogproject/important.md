#in mega project there are so many thing we have to install 
1-@reduxjs/toolskit
2-react-redux
3-react-router-dom
4-appwrite(for backend purpose bcz in react we can only perform frontend development)
5-@tinymce/tinymce(for font styling)
6-html-react-parser(this is for parse the in html form which tags we will write)




# steps for appwrite site
1-go to appwrite link "https://appwrite.io/"

2-signin or sign up

3-create project

4- goto setting and copy the projectId and paste it into the .env

5-then create a database and copy the database id and paste it into the .env

6-create collection and copy the collection id

7- vvimp step-- 
go to the collection and then go tot the colelction setting and in collection setting and in select the "permission option and select to the permisions

8- goto storage and create bucket andcopy the id and paste in .env and go to setting of bucket and change the permissions
